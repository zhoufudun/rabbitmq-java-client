# RabbitMQ protocol code-generation and machine-readable spec

## This was migrated to https://github.com/rabbitmq/rabbitmq-server

This repository has been moved to the main unified RabbitMQ "monorepo", including all open issues. You can find the source under [/deps/rabbitmq_codegen](https://github.com/rabbitmq/rabbitmq-server/tree/master/deps/rabbitmq_codegen).
All issues have been transferred.
